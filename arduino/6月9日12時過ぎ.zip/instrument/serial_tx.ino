// serial_tx.ino
#include "score_data.h"

const uint8_t SERIAL_HEADER_NOTE_ON  = 0x90;
const uint8_t SERIAL_HEADER_NOTE_OFF = 0x80;

void init_serial_tx() {
    Serial.begin(115200);
}

void serial_tx_note_on(uint8_t pitch, uint8_t velocity) {
    Serial.write(SERIAL_HEADER_NOTE_ON);
    Serial.write(pitch);
    Serial.write(velocity);
}

void serial_tx_note_off(uint8_t pitch) {
    Serial.write(SERIAL_HEADER_NOTE_OFF);
    Serial.write(pitch);
    Serial.write(0);
}