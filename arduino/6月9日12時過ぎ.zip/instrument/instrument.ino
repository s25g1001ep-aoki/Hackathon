// main.ino
#include "score_data.h"

extern volatile bool is_playing;
extern volatile uint16_t local_tick;
extern volatile bool spi_error_flag;
extern volatile uint8_t error_count;

extern void init_serial_tx();
extern void instrument_id_init();
extern uint8_t get_instrument_id();
extern void score_init(uint8_t instrument_id);
extern void init_spi_slave();
extern void sync_init();
extern void init_pressure_sensor();

extern void score_step(uint16_t local_tick);
extern void score_loop_check(uint16_t &local_tick);
extern void score_stop_all();
extern void pressure_sensor_step();

void setup() {
    init_serial_tx();
    instrument_id_init();
    score_init(get_instrument_id());
    init_spi_slave();
    sync_init();
    init_pressure_sensor();
}

void loop() {
    pressure_sensor_step();

    if (spi_error_flag && error_count >= 3) {
        is_playing = false;
        score_stop_all();
        spi_error_flag = false;
        error_count = 0;
    }

    if (is_playing) {
        noInterrupts();
        uint16_t current_tick = local_tick;
        interrupts();

        score_step(current_tick);
        score_loop_check(local_tick);
    }
}