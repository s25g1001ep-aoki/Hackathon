// spi_slave.ino
#include "score_data.h"

const int SS_PIN = 10;

enum ControlCommand {
    CMD_PLAY = 0x01,
    CMD_STOP = 0x02,
    CMD_ENTRY_CUE = 0x03,
    CMD_BPM_UPDATE = 0x04
};

volatile bool is_playing = false;
volatile bool spi_error_flag = false;
volatile uint8_t error_count = 0;

extern volatile uint16_t local_tick;
extern uint8_t frog_state;
extern void score_init(uint8_t instrument_id);
extern void score_stop_all();
extern uint8_t get_instrument_id();

void init_spi_slave() {
    pinMode(MISO, OUTPUT);
    pinMode(MOSI, INPUT);
    pinMode(SCK, INPUT);
    pinMode(SS_PIN, INPUT);

    SPCR |= _BV(SPE);
    SPCR |= _BV(SPIE);
}

ISR(SPI_STC_vect) {
    uint8_t rx_byte = SPDR;
    uint8_t command = (rx_byte >> 4) & 0x0F;
    uint8_t checksum = rx_byte & 0x0F;

    if ((command ^ 0x0F) != checksum) {
        error_count++;
        spi_error_flag = true;
        SPDR = 0xFF;
        return;
    }

    error_count = 0;

    switch (command) {
        case CMD_PLAY:
            is_playing = true;
            break;
        case CMD_STOP:
            is_playing = false;
            score_stop_all();
            break;
        case CMD_ENTRY_CUE:
            noInterrupts();
            local_tick = 0;
            interrupts();
            score_init(get_instrument_id());
            is_playing = true;
            break;
        case CMD_BPM_UPDATE:
            break;
    }

    uint8_t instrument_status = frog_state;
    SPDR = instrument_status;
}